Every prompt is composed of:
    