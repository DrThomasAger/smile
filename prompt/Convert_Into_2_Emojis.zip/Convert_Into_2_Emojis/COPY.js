#!/usr/bin/env node
/**
 * COPY.js — v2.3 (compile‑first + indexed suggestions)
 *
 * What changed in v2.3 (to fix your “stall”):
 * 1) **Compile first, warn later.** We no longer do suggestion lookups before compiling.
 *    Each file prints `[WORK] ...` then compiles immediately; warnings are gathered in a
 *    second pass after all .txt outputs are written.
 * 2) **Indexed lookups.** We build an in‑memory index of names → files once (chain/document
 *    `.smile`, data any ext). All suggestions and resolutions use the index = no deep re‑walks.
 * 3) Same rules as v2: only `chain/`, `document/`, `data/`. Output `foo.smile → foo.txt` for
 *    every `.smile` that contains at least one reference token.
 *
 * CLI:
 *   node COPY.js [--no-suggest] [--debug] [project-root]
 *
 * Zero dependencies. Node >= 14.
 */

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

// ------------------------------ Config ------------------------------ //
const ALLOWED_TYPES = new Set(["chain", "document", "data"]);
const LEGACY_ALIASES = {
  doc: "document",
  docs: "document",
  section: "document",
  sections: "document",
  pipeline: "chain",
  module: "chain",
  modules: "chain",
  var: "data",
  variable: "data",
  variables: "data",
  segment: "data",
  segments: "data",
  folder: "document", // common legacy token
};
const LEGACY_SUBTYPES = new Set(["prompt", "response"]);
const IGNORE_DIRS = new Set([".git","node_modules",".smile-log",".idea",".vscode"]);
const PRUNE_DIRS  = new Set(["build","dist","coverage",".next",".turbo","out",".cache","tmp","temp","__pycache__","venv",".venv","env",".env","target","bazel-bin","bazel-out",".gradle",".m2",".DS_Store"]);
const LOG_DIR = ".smile-log";
const VERSION_FILE = path.join(LOG_DIR, "version.json");
const WARNINGS_FILE = path.join(LOG_DIR, "warnings.json");

// Reference token regex
const REF_RE   = /\[\$(?<inner>[^\]]*?)\$\]/g;
const INNER_RE = /^(?<lead>\s*)(?<type>[A-Za-z]+)?(?:\/(?<subtype>[A-Za-z]+))?(?<mid>\s*)(?<op>=|:)?(?<mid2>\s*)(?:"(?<qname>[^"]+)"|(?<name>[A-Za-z0-9._\-\s]+))?(?<trail>\s*)$/;

// ------------------------------ CLI ------------------------------ //
function printHelp(){
  console.log(`\nUsage: node COPY.js [options] [project-root]\n\nOptions:\n  --no-suggest   Skip auto-suggestions in warnings (fastest)\n  --debug        Print timing details\n  -h, --help     Show this help\n`);
}
function parseArgs(argv){
  const out = { root:null, noSuggest:false, debug:false };
  for (const a of argv){
    if (a === "--no-suggest") out.noSuggest = true; else
    if (a === "--debug")      out.debug     = true; else
    if (a === "-h"||a==="--help"){ printHelp(); process.exit(0); }
    else if (!a.startsWith("-")) out.root = path.resolve(a);
  }
  return out;
}

// ------------------------------ Small utils ------------------------------ //
const hash      = (buf)=>crypto.createHash("md5").update(buf).digest("hex");
const readText  = (p)=>fs.readFileSync(p, "utf8");
const writeText = (p,s)=>fs.writeFileSync(p,s,"utf8");
const ensureDir = (p)=>fs.mkdirSync(p,{recursive:true});

const normName = (s)=> s.toLowerCase().replace(/\s+/g,"").replace(/[\-_]+/g,"").replace(/\.(smile|txt)$/i,"");
function safeLstat(p){ try{return fs.lstatSync(p);}catch{ return null; } }
function real(p){ try{ return fs.realpathSync.native?fs.realpathSync.native(p):fs.realpathSync(p);}catch{ return p; } }
function posToLineCol(text, index){ let line=1,col=1; for(let i=0;i<index;i++){ if(text.charCodeAt(i)===10){line++;col=1;} else {col++;} } return {line,col}; }

// ------------------------------ Walk helpers ------------------------------ //
function walkDirs(startDirs, fileFilter){
  const out=[]; const visited=new Set();
  function walk(dir){
    const st=safeLstat(dir); if(!st) return; if(st.isSymbolicLink()) return;
    const rp=real(dir); if(visited.has(rp)) return; visited.add(rp);
    let entries; try{ entries=fs.readdirSync(dir,{withFileTypes:true}); }catch{ return; }
    for(const e of entries){
      if(IGNORE_DIRS.has(e.name)||PRUNE_DIRS.has(e.name)) continue;
      const full=path.join(dir,e.name); const est=safeLstat(full); if(!est) continue; if(est.isSymbolicLink()) continue;
      if(est.isDirectory()) walk(full); else if(est.isFile() && fileFilter(full)) out.push(full);
    }
  }
  for(const d of startDirs) walk(d);
  return out;
}

function walkSmileFiles(root){
  const preferred=["chain","document","data"].map(d=>path.join(root,d)).filter(p=>fs.existsSync(p));
  const startDirs=preferred.length?preferred:[root];
  return walkDirs(startDirs, f=>f.toLowerCase().endsWith('.smile'));
}

// ------------------------------ Index (names → files) ------------------------------ //
function buildIndex(root){
  const idx={ chain:new Map(), document:new Map(), data:new Map(), all:new Map() };
  function add(type, full){ const key=normName(path.basename(full)); const rec={full,type};
    const m=idx[type]; if(!m.has(key)) m.set(key,[]); m.get(key).push(rec);
    if(!idx.all.has(key)) idx.all.set(key,[]); idx.all.get(key).push(rec);
  }
  const chainDir=path.join(root,'chain');
  const docDir  =path.join(root,'document');
  const dataDir =path.join(root,'data');
  if (fs.existsSync(chainDir)) walkDirs([chainDir], f=>f.toLowerCase().endsWith('.smile')).forEach(f=>add('chain',f));
  if (fs.existsSync(docDir))   walkDirs([docDir],   f=>f.toLowerCase().endsWith('.smile')).forEach(f=>add('document',f));
  if (fs.existsSync(dataDir))  walkDirs([dataDir],  _=>true).forEach(f=>add('data',f)); // any ext for data
  return idx;
}

// ------------------------------ Candidate search (indexed) ------------------------------ //
function findCandidatesIndexed(index, nameRaw, typeHint){
  const key=normName(nameRaw);
  if (typeHint && ALLOWED_TYPES.has(typeHint)) return index[typeHint].get(key)||[];
  return index.all.get(key)||[];
}

// ------------------------------ Warning model ------------------------------ //
function warnNonCompliant({ filePath, text, token, matchIndex, details, suggestions }){
  const {line,col}=posToLineCol(text, matchIndex);
  return {
    file:path.resolve(filePath), line, column:col, token, details,
    suggestions:(suggestions||[]).map(s=>({ type:s.type, path:s.full, suggestedReference:`[$${s.type}="${path.basename(s.full).replace(/\.(smile|txt)$/i,"")}"$]` }))
  };
}

function scanForNonCompliance(index, filePath, text, { noSuggest=false }={}){
  const warnings=[]; REF_RE.lastIndex=0; let m;
  while((m=REF_RE.exec(text))){
    const token=m[0]; const inner=m.groups.inner; const parsed=INNER_RE.exec(inner); const start=m.index;
    if(!parsed){ warnings.push(warnNonCompliant({filePath,text,token,matchIndex:start,details:"Malformed reference token."})); continue; }
    const type = parsed.groups.type ? parsed.groups.type.trim() : undefined;
    const subtype = parsed.groups.subtype ? parsed.groups.subtype.trim() : undefined;
    const name = (parsed.groups.qname ?? parsed.groups.name ?? "").trim();

    if(!type){
      const suggestions = (noSuggest||!name)?[]:findCandidatesIndexed(index,name,undefined);
      warnings.push(warnNonCompliant({filePath,text,token,matchIndex:start,details:"Missing type — use one of: chain, document, data.",suggestions}));
      continue;
    }
    const typeLower=type.toLowerCase();

    if(!ALLOWED_TYPES.has(typeLower)){
      const aliased=LEGACY_ALIASES[typeLower];
      const details= aliased?`Legacy type "${type}" — use "${aliased}".`:`Unknown type "${type}" — use chain/document/data.`;
      const suggestions=(noSuggest||!name)?[]:findCandidatesIndexed(index,name,aliased);
      warnings.push(warnNonCompliant({filePath,text,token,matchIndex:start,details,suggestions}));
    }
    if(subtype){
      const normalized=ALLOWED_TYPES.has(typeLower)?typeLower:(LEGACY_ALIASES[typeLower]||"document");
      const details = LEGACY_SUBTYPES.has(subtype.toLowerCase())
        ? `Legacy subtype "/${subtype}" — prompt/response folders are removed. Put all files under "${normalized}" and remove the subtype.`
        : `Subtypes are unsupported in v2 — remove "/${subtype}".`;
      const suggestions=(noSuggest||!name)?[]:findCandidatesIndexed(index,name,normalized);
      warnings.push(warnNonCompliant({filePath,text,token,matchIndex:start,details,suggestions}));
    }
    if(name){
      const declared=ALLOWED_TYPES.has(typeLower)?typeLower:LEGACY_ALIASES[typeLower];
      if(declared){
        const found = (noSuggest)?[]:findCandidatesIndexed(index,name,undefined);
        if(found.length && found.every(f=>f.type!==declared)){
          warnings.push(warnNonCompliant({filePath,text,token,matchIndex:start,details:`Name "${name}" found, but not under declared type "${declared}". Consider updating the type to match the actual location.`,suggestions:found}));
        }
      }
    }
  }
  return warnings;
}

// ------------------------------ Resolver & Compiler ------------------------------ //
function parseInner(inner){ const m=INNER_RE.exec(inner); if(!m) return null; const {type,subtype,qname,name}=m.groups; return { type:type?type.trim():undefined, subtype:subtype?subtype.trim():undefined, name:(qname??name??"").trim() }; }
function readCandidateContent(c){ try{ return readText(c.full);}catch(e){ throw new Error(`Failed to read candidate ${c.full}: ${e.message}`);} }

function resolveReference(index, ref, ctx){
  const { currentFile, stack } = ctx; const { type, subtype, name } = ref;
  const declaredType = type ? (LEGACY_ALIASES[type.toLowerCase()] || type.toLowerCase()) : undefined;
  const candidates = findCandidatesIndexed(index, name, declaredType);
  if(candidates.length>1){ const list=candidates.map(c=>`- ${c.type}: ${c.full}`).join("\n"); throw new Error(`Ambiguous reference "${type||"?"}${subtype?"/"+subtype:""}=${name}" in ${currentFile}\n${list}\nSpecify the correct type explicitly.`); }
  if(candidates.length===0){ throw new Error(`Cannot resolve "${type||"?"}${subtype?"/"+subtype:""}=${name}" from ${currentFile}.`); }
  const target=candidates[0].full; if(stack.includes(target)){ const cycle=[...stack,target].map(p=>path.relative(process.cwd(),p)).join(" -> "); throw new Error(`Include cycle detected: ${cycle}`);} 
  const content=readCandidateContent(candidates[0]);
  return compileContent(index, { filePath:target, text:content, stack:[...stack,target] });
}

function compileContent(index, { filePath, text, stack }){
  REF_RE.lastIndex=0; let out=""; let last=0; let m;
  while((m=REF_RE.exec(text))){
    out+=text.slice(last,m.index);
    const inner=m.groups.inner; const parsed=parseInner(inner);
    if(!parsed||!parsed.name){ throw new Error(`Malformed or empty reference token in ${filePath} at index ${m.index}`); }
    const inlined=resolveReference(index, parsed, { currentFile:filePath, stack });
    out+=inlined; last=m.index+m[0].length;
  }
  out+=text.slice(last);
  return out.replace(/\r\n/g,"\n").replace(/\n{3,}/g,"\n\n");
}

function compileFile(index, filePath){
  const src=readText(filePath);
  if(!hasRefs(src)) return null; // skip files without references
  return compileContent(index, { filePath, text:src, stack:[filePath] });
}

function hasRefs(text){ REF_RE.lastIndex=0; return REF_RE.test(text); }
function writeCompiledNextToSource(filePath, compiled){ const out=path.join(path.dirname(filePath), path.basename(filePath).replace(/\.(smile)$/i, ".txt")); writeText(out, compiled); return out; }

// ------------------------------ Versioning ------------------------------ //
function loadJsonSafe(p){ try{ return JSON.parse(readText(p)); }catch{ return null; } }
function saveJson(p,obj){ ensureDir(path.dirname(p)); writeText(p, JSON.stringify(obj,null,2)); }
function computeHashes(files){ const map={}; for(const f of files){ try{ map[f]=hash(readText(f)); }catch{} } return map; }
function updateVersionLog(allFiles){ const prev=loadJsonSafe(VERSION_FILE)||{version:0,files:{},history:[]}; const nextFiles=computeHashes(allFiles); const changed=Object.keys(nextFiles).filter(k=>prev.files[k]!==nextFiles[k]); if(changed.length){ const version=prev.version+1; const entry={version,timestamp:new Date().toISOString(),changed}; const next={version,files:nextFiles,history:[...(prev.history||[]),entry]}; saveJson(VERSION_FILE,next);} else if(!fs.existsSync(VERSION_FILE)){ saveJson(VERSION_FILE,{version:1,files:nextFiles,history:[{version:1,timestamp:new Date().toISOString(),changed:Object.keys(nextFiles)}]}); } }

// ------------------------------ Main ------------------------------ //
function main(){
  const args=parseArgs(process.argv.slice(2));
  const cliRoot=args.root||null; const root=cliRoot||process.cwd();
  console.log(`[INFO] Scanning for .smile files under: ${root}`);
  const smileFiles=walkSmileFiles(root);
  console.log(`[INFO] Found ${smileFiles.length} .smile file(s).`);

  // Build index once
  const t0=Date.now();
  const index=buildIndex(root);
  console.log(`[INFO] Indexed names in ${Date.now()-t0}ms (chain=${index.chain.size}, document=${index.document.size}, data=${index.data.size}).`);

  const warnings=[]; const compiledOutputs=[];

  // Pass 1: compile immediately
  for(const f of smileFiles){
    try{
      console.log(`[WORK] Compiling ${path.relative(root,f)} …`);
      const compiled=compileFile(index, f);
      if(compiled!==null){ const outPath=writeCompiledNextToSource(f,compiled); compiledOutputs.push(outPath); console.log(`[OK] ${path.relative(root,f)} -> ${path.relative(root,outPath)}`);} else { console.log(`[SKIP] No references in ${path.relative(root,f)}`);}    
    }catch(e){
      warnings.push({ file:path.resolve(f), line:0, column:0, token:"", details:`ERROR: ${e.message}`, suggestions:[] });
      console.error(`[ERROR] ${f}: ${e.message}`);
    }
  }

  // Pass 2: warnings (suggestions optionally suppressed)
  for(const f of smileFiles){
    try{ const src=readText(f); const ws=scanForNonCompliance(index, f, src, { noSuggest: args.noSuggest }); warnings.push(...ws); }catch{/* ignore */}
  }

  // Persist warnings & versioning
  ensureDir(LOG_DIR);
  saveJson(WARNINGS_FILE, { generatedAt:new Date().toISOString(), warnings });
  updateVersionLog([ ...smileFiles, ...compiledOutputs ]);

  // Pretty print warnings at the end
  if(warnings.length){
    console.log("\nWarnings / Non‑compliant references:");
    for(const w of warnings){
      const loc=`${w.file}:${w.line}:${w.column}`;
      console.log(`- ${loc}: ${w.details}\n  Token: ${w.token || "(n/a)"}`);
      if(w.suggestions && w.suggestions.length){
        for(const s of w.suggestions.slice(0,5)){
          console.log(`  Suggest: ${s.suggestedReference}  ->  ${s.path}`);
        }
      }
    }
  }

  console.log(`\nDone. Compiled ${compiledOutputs.length} file(s). Warnings: ${warnings.length}.`);
}

if(require.main===module){ try{ main(); }catch(e){ console.error(e); process.exit(1); } }
